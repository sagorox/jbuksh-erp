import 'dart:convert';
import 'package:flutter/material.dart';
import '../../core/api.dart';
import '../../core/auth_client.dart';
import '../../models/invoice.dart';
import '../../models/party.dart';
import '../../widgets/quick_links_card.dart';
import '../../widgets/search_bar_row.dart';
import '../../widgets/segmented_switch.dart';
import '../../widgets/txn_card.dart';
import '../../widgets/party_row.dart';
import '../../routes.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int seg = 0; // 0=Transaction, 1=Party
  bool loading = true; //
  String? err; //

  String q = ""; //

  List<Invoice> invoices = []; //
  List<Party> parties = []; //

  // অ্যামাউন্ট ফরম্যাট করার জন্য হেল্পার ফাংশন
  String money(num v) => v.toStringAsFixed(2); //

  Future<void> load() async {
    setState(() {
      loading = true;
      err = null;
    });

    try {
      // fetch invoices sequential
      final invRes = await AuthClient.get(Uri.parse("${Api.baseUrl}/api/v1/invoices"));
      if (invRes.statusCode < 200 || invRes.statusCode >= 300) {
        setState(() => err = "Invoices error ${invRes.statusCode}: ${invRes.body}");
        return;
      }

      final invData = jsonDecode(invRes.body);
      final invList = invData is List ? invData : (invData["items"] ?? []);
      invoices = (invList as List).map((e) => Invoice.fromJson(e)).toList();

      // fetch parties
      final pRes = await AuthClient.get(Uri.parse("${Api.baseUrl}/api/v1/parties"));
      if (pRes.statusCode < 200 || pRes.statusCode >= 300) {
        setState(() => err = "Parties error ${pRes.statusCode}: ${pRes.body}");
        return;
      }

      final pData = jsonDecode(pRes.body);
      final pList = pData is List ? pData : (pData["items"] ?? []);
      parties = (pList as List).map((e) => Party.fromJson(e)).toList();
    } catch (e) {
      setState(() => err = "$e");
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  Widget build(BuildContext context) {
    // সার্চ ফিল্টারিং লজিক
    final filteredInvoices = invoices.where((i) {
      if (q.isEmpty) return true;
      final s = "${i.partyName} ${i.invoiceNo}".toLowerCase();
      return s.contains(q.toLowerCase());
    }).toList();

    final filteredParties = parties.where((p) {
      if (q.isEmpty) return true;
      final s = "${p.name} ${p.partyCode}".toLowerCase();
      return s.contains(q.toLowerCase());
    }).toList();

    return Stack(
      children: [
        if (loading)
          const Center(child: CircularProgressIndicator())
        else if (err != null)
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("Failed: $err"),
                const SizedBox(height: 12),
                ElevatedButton(onPressed: load, child: const Text("Retry")),
              ],
            ),
          )
        else
          RefreshIndicator(
            onRefresh: load,
            child: ListView(
              padding: const EdgeInsets.only(top: 12, bottom: 90),
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: SegmentedSwitch(
                    index: seg,
                    labels: const ["Transaction Details", "Party Details"],
                    onChanged: (i) => setState(() {
                      seg = i;
                      q = "";
                    }),
                  ),
                ),
                const SizedBox(height: 12),
                QuickLinksCard(
                  items: seg == 0
                      ? [
                          QuickLinkItem(
                            icon: Icons.bookmark_add,
                            label: "Add Txn",
                            onTap: () => Navigator.of(context).pushNamed(RouteNames.addSale),
                          ),
                          QuickLinkItem(
                            icon: Icons.receipt_long,
                            label: "Sale Report",
                            onTap: () => Navigator.of(context).pushNamed(
                              RouteNames.reportFilter,
                              arguments: {'reportKey': 'Sales Report'},
                            ),
                          ),
                          QuickLinkItem(
                            icon: Icons.settings,
                            label: "Txn Settings",
                            onTap: () => Navigator.of(context).pushNamed(RouteNames.settings),
                          ),
                          QuickLinkItem(
                            icon: Icons.arrow_forward,
                            label: "Show All",
                            onTap: () => Navigator.of(context).pushNamed(RouteNames.transactions),
                          ),
                        ]
                      : [
                          QuickLinkItem(
                            icon: Icons.currency_rupee,
                            label: "Take Payment",
                            onTap: () => Navigator.of(context).pushNamed(RouteNames.collections),
                          ),
                          QuickLinkItem(
                            icon: Icons.assignment,
                            label: "Party State...",
                            onTap: () => Navigator.of(context).pushNamed(
                              RouteNames.reportFilter,
                              arguments: {'reportKey': 'Party Statement'},
                            ),
                          ),
                          QuickLinkItem(
                            icon: Icons.settings,
                            label: "Party Settings",
                            onTap: () => Navigator.of(context).pushNamed(RouteNames.settings),
                          ),
                          QuickLinkItem(
                            icon: Icons.arrow_forward,
                            label: "Show All",
                            onTap: () => Navigator.of(context).pushNamed(RouteNames.parties),
                          ),
                        ],
                ),
                const SizedBox(height: 12),
                SearchBarRow(
                  hint: "Search item / party / transaction",
                  onChanged: (v) => setState(() => q = v),
                  onFilterTap: () {},
                  onMoreTap: () {},
                ),
                const SizedBox(height: 6),

                if (seg == 0) ...[
                  if (filteredInvoices.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(20),
                      child: Center(child: Text("No transactions")),
                    )
                  else
                    ...filteredInvoices.map((inv) {
                      final unpaid = inv.dueAmount > 0;
                      return TxnCard(
                        party: "CP: ${inv.partyName}",
                        badge: unpaid ? "SALE : UNPAID" : "SALE : PAID",
                        invoiceNo: inv.invoiceNo.isEmpty ? "-" : inv.invoiceNo,
                        date: inv.invoiceDate.isEmpty ? "-" : inv.invoiceDate,
                        totalLabel: "Total",
                        // অ্যামাউন্ট ফরম্যাট করা হয়েছে
                        total: "৳ ${money(inv.netTotal)}", //
                        balanceLabel: "Balance",
                        balance: "৳ ${money(inv.dueAmount)}", //
                      );
                    }),
                ] else ...[
                  if (filteredParties.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(20),
                      child: Center(child: Text("No parties")),
                    )
                  else
                    ...filteredParties.map((p) {
                      return PartyRow(
                        name: "CP: ${p.name}",
                        date: p.partyCode,
                        amount: "৳ 0.00",
                      );
                    }),
                ],
              ],
            ),
          ),

        Positioned(
          left: 0,
          right: 0,
          bottom: 18,
          child: Center(
            child: SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFE53935),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                ),
                onPressed: () => Navigator.of(context).pushNamed(
                  seg == 0 ? RouteNames.addSale : RouteNames.addParty,
                ),
                icon: Icon(seg == 0 ? Icons.currency_rupee : Icons.person_add),
                label: Text(seg == 0 ? "Add New Sale" : "Add New Party",
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
