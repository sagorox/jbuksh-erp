import 'package:flutter/material.dart';

import '../../core/local_store.dart';
import 'feature_scaffold.dart';

class InvoicePreviewScreen extends StatelessWidget {
  final Map<String, dynamic> invoice;
  const InvoicePreviewScreen({super.key, required this.invoice});

  num _toNum(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    return num.tryParse(v.toString()) ?? 0;
  }

  String _invoiceNo(Map<String, dynamic> inv) {
    final serverNo = (inv['server_invoice_no'] ?? '').toString().trim();
    if (serverNo.isNotEmpty) return serverNo;
    return (inv['invoice_no'] ?? '-').toString();
  }

  bool _isTemp(Map<String, dynamic> inv) {
    final serverNo = (inv['server_invoice_no'] ?? '').toString().trim();
    final localNo = (inv['invoice_no'] ?? '').toString().trim();
    return serverNo.isEmpty && localNo.startsWith('DRAFT-');
  }

  @override
  Widget build(BuildContext context) {
    final partyId = invoice['party_id'] ?? invoice['party']?['id'];
    final party = LocalStore.allBoxMaps('parties').firstWhere(
          (p) => (p['id'] ?? p['server_id']) == partyId,
          orElse: () => <String, dynamic>{},
        );

    final items = (invoice['items'] is List) ? (invoice['items'] as List).whereType<Map>().map((e) => e.cast<String, dynamic>()).toList() : <Map<String, dynamic>>[];
    final invoiceNo = _invoiceNo(invoice);
    final isTemp = _isTemp(invoice);

    return FeatureScaffold(
      title: 'Invoice Preview',
      actions: [
        IconButton(
          tooltip: 'Save PDF (later)',
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('PDF generation will be hooked later.')),
            );
          },
          icon: const Icon(Icons.picture_as_pdf_outlined),
        ),
        IconButton(
          tooltip: 'Share (later)',
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Share integration will be connected next.')),
            );
          },
          icon: const Icon(Icons.share_outlined),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Company: JBCL', style: const TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: Text('Invoice: $invoiceNo')),
                      if (isTemp)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(color: Colors.orange.shade100, borderRadius: BorderRadius.circular(999)),
                          child: Text('TEMP', style: TextStyle(fontSize: 10, color: Colors.orange.shade900, fontWeight: FontWeight.w700)),
                        ),
                    ],
                  ),
                  Text('Date: ${invoice['invoice_date'] ?? '-'}'),
                  Text('Status: ${(invoice['status'] ?? '-').toString()}'),
                  const Divider(height: 20),
                  Text('Party: ${party['name'] ?? invoice['party_name'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  if ((party['phone'] ?? '').toString().isNotEmpty) Text('Phone: ${party['phone']}'),
                  if ((party['address'] ?? '').toString().isNotEmpty) Text('Address: ${party['address']}'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Items', style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  for (final it in items)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(child: Text((it['name'] ?? it['product_name'] ?? it['sku'] ?? '-').toString())),
                          const SizedBox(width: 8),
                          Text('${_toNum(it['qty']).toStringAsFixed(0)} x ${_toNum(it['unit_price']).toStringAsFixed(2)}'),
                          const SizedBox(width: 8),
                          Text(_toNum(it['line_total']).toStringAsFixed(2), style: const TextStyle(fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ),
                  const Divider(height: 20),
                  _kv('Subtotal', _toNum(invoice['subtotal']).toStringAsFixed(2)),
                  _kv('Discount', _toNum(invoice['discount_amount']).toStringAsFixed(2)),
                  _kv('Net Total', _toNum(invoice['net_total']).toStringAsFixed(2), bold: true),
                  _kv('Received', _toNum(invoice['received_amount']).toStringAsFixed(2)),
                  _kv('Due', _toNum(invoice['due_amount']).toStringAsFixed(2), bold: true),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _kv(String k, String v, {bool bold = false}) {
    final st = TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w500);
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Expanded(child: Text(k, style: st)),
          Text(v, style: st),
        ],
      ),
    );
  }
}
