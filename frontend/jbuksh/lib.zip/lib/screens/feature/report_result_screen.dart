import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

import '../../core/api.dart';
import '../../core/export_utils.dart';
import '../../core/local_store.dart';
import 'feature_scaffold.dart';

class ReportResultScreen extends StatefulWidget {
  final Map<String, dynamic> args;
  const ReportResultScreen({super.key, required this.args});

  @override
  State<ReportResultScreen> createState() => _ReportResultScreenState();
}

class _ReportResultScreenState extends State<ReportResultScreen> {
  bool _loading = true;
  String? _error;
  late String _reportKey;
  late DateTime _from;
  late DateTime _to;
  dynamic _partyId;
  dynamic _status;
  List<Map<String, dynamic>> _rows = [];

  @override
  void initState() {
    super.initState();
    _reportKey = (widget.args['reportKey'] ?? 'Report').toString();
    _from = _dt(widget.args['from'] ?? DateTime.now().toIso8601String());
    _to = _dt(widget.args['to'] ?? DateTime.now().toIso8601String());
    _partyId = widget.args['partyId'];
    _status = widget.args['status'];
    _load();
  }

  DateTime _dt(String iso) {
    try {
      return DateTime.parse(iso);
    } catch (_) {
      return DateTime.now();
    }
  }

  num _toNum(dynamic v) {
    if (v is num) return v;
    return num.tryParse(v?.toString() ?? '') ?? 0;
  }

  bool _inRange(String? d, DateTime from, DateTime to) {
    if (d == null || d.isEmpty) return false;
    try {
      final dt = DateTime.parse(d);
      return !dt.isBefore(DateTime(from.year, from.month, from.day)) &&
          !dt.isAfter(DateTime(to.year, to.month, to.day, 23, 59, 59));
    } catch (_) {
      return false;
    }
  }

  String _ymd(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final rows = await _buildRows();
      if (!mounted) return;
      setState(() => _rows = rows);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<List<Map<String, dynamic>>> _buildRows() async {
    final invoicesAll = LocalStore.allBoxMaps('invoices');
    final collectionsAll = LocalStore.allBoxMaps('collections');
    final expensesAll = LocalStore.allBoxMaps('expenses');
    final productsAll = LocalStore.allBoxMaps('products');
    final vouchersAll = Hive.box('vouchers')
        .values
        .whereType<Map>()
        .map((e) => e.cast<String, dynamic>())
        .toList();

    if (_reportKey == 'Sales Report') {
      try {
        final res = await Api.getJson(
          '/api/v1/reports/sales-summary?from=${_ymd(_from)}&to=${_ymd(_to)}${_partyId == null ? '' : '&party_id=$_partyId'}',
        );
        final s = (res['summary'] as Map?)?.cast<String, dynamic>() ?? const {};
        return [
          {'label': 'Total Invoices', 'value': _toNum(s['total_invoices'])},
          {'label': 'Approved Invoices', 'value': _toNum(s['approved_invoices'])},
          {'label': 'Gross Sales', 'value': _toNum(s['gross_sales'])},
          {'label': 'Discount', 'value': _toNum(s['total_discount'])},
          {'label': 'Net Sales', 'value': _toNum(s['net_sales'])},
          {'label': 'Received Amount', 'value': _toNum(s['received_amount'])},
          {'label': 'Outstanding Due', 'value': _toNum(s['outstanding_due'])},
        ];
      } catch (_) {
        return invoicesAll.where((e) {
          final okDate = _inRange(e['invoice_date']?.toString(), _from, _to);
          final okParty = _partyId == null ? true : (e['party_id'] ?? (e['party']?['id'])) == _partyId;
          final okStatus = _status == null ? true : (e['status'] ?? '').toString() == _status;
          return okDate && okParty && okStatus;
        }).toList();
      }
    }

    if (_reportKey == 'Collection Summary') {
      try {
        final res = await Api.getJson(
          '/api/v1/reports/collections-summary?from=${_ymd(_from)}&to=${_ymd(_to)}${_partyId == null ? '' : '&party_id=$_partyId'}',
        );
        final s = (res['summary'] as Map?)?.cast<String, dynamic>() ?? const {};
        return [
          {'label': 'Total Collections', 'value': _toNum(s['total_collections'])},
          {'label': 'Approved Collections', 'value': _toNum(s['approved_collections'])},
          {'label': 'Total Amount', 'value': _toNum(s['total_amount'])},
          {'label': 'Approved Amount', 'value': _toNum(s['approved_amount'])},
          {'label': 'Allocated Amount', 'value': _toNum(s['allocated_amount'])},
          {'label': 'Unused Amount', 'value': _toNum(s['unused_amount'])},
        ];
      } catch (_) {
        return collectionsAll.where((e) {
          final sameParty = _partyId == null || (e['party_id'] ?? (e['party']?['id'])) == _partyId;
          return sameParty && _inRange(e['collection_date']?.toString(), _from, _to);
        }).toList();
      }
    }

    if (_reportKey == 'Expense Summary') {
      try {
        final res = await Api.getJson('/api/v1/reports/expense-summary?from=${_ymd(_from)}&to=${_ymd(_to)}');
        final s = (res['summary'] as Map?)?.cast<String, dynamic>() ?? const {};
        return [
          {'label': 'Total Expenses', 'value': _toNum(s['total_expenses'])},
          {'label': 'Approved Expenses', 'value': _toNum(s['approved_expenses'])},
          {'label': 'Total Amount', 'value': _toNum(s['total_amount'])},
          {'label': 'Approved Amount', 'value': _toNum(s['approved_amount'])},
          {'label': 'Declined Amount', 'value': _toNum(s['declined_amount'])},
        ];
      } catch (_) {
        return expensesAll.where((e) => _inRange(e['expense_date']?.toString(), _from, _to)).toList();
      }
    }

    if (_reportKey == 'Stock Summary') {
      try {
        final res = await Api.getJson('/api/v1/reports/stock-summary?from=${_ymd(_from)}&to=${_ymd(_to)}');
        final s = (res['summary'] as Map?)?.cast<String, dynamic>() ?? const {};
        return [
          {'label': 'Total Products', 'value': _toNum(s['total_products'])},
          {'label': 'Active Products', 'value': _toNum(s['active_products'])},
          {'label': 'Stock Qty', 'value': _toNum(s['total_stock_qty'])},
          {'label': 'Stock Value (Purchase)', 'value': _toNum(s['stock_value_purchase'])},
          {'label': 'Stock Value (Sale)', 'value': _toNum(s['stock_value_sale'])},
          {'label': 'Low Stock Count', 'value': _toNum(s['low_stock_count'])},
          {'label': 'Out of Stock Count', 'value': _toNum(s['out_of_stock_count'])},
        ];
      } catch (_) {
        final totalItems = productsAll.length;
        final stockValue = productsAll.fold<num>(0, (s, e) => s + (_toNum(e['in_stock']) * _toNum(e['purchase_price'])));
        final lowCount = productsAll.where((e) => _toNum(e['reorder_level']) > 0 && _toNum(e['in_stock']) <= _toNum(e['reorder_level'])).length;
        return [
          {'label': 'Total Items', 'value': totalItems},
          {'label': 'Low Stock Items', 'value': lowCount},
          {'label': 'Stock Value', 'value': stockValue},
        ];
      }
    }

    if (_reportKey == 'Party Statement') {
      final rows = <Map<String, dynamic>>[];
      final inv = invoicesAll.where((e) {
        final sameParty = _partyId != null && (e['party_id'] ?? (e['party']?['id'])) == _partyId;
        return sameParty && _inRange(e['invoice_date']?.toString(), _from, _to);
      });
      final col = collectionsAll.where((e) {
        final sameParty = _partyId != null && (e['party_id'] ?? (e['party']?['id'])) == _partyId;
        return sameParty && _inRange(e['collection_date']?.toString(), _from, _to);
      });
      for (final e in inv) {
        rows.add({'date': e['invoice_date'] ?? '-', 'type': 'INVOICE', 'ref': e['invoice_no'] ?? '-', 'debit': _toNum(e['net_total']), 'credit': 0});
      }
      for (final e in col) {
        rows.add({'date': e['collection_date'] ?? '-', 'type': 'PAYMENT', 'ref': e['collection_no'] ?? '-', 'debit': 0, 'credit': _toNum(e['amount'])});
      }
      rows.sort((a, b) => (a['date'] ?? '').toString().compareTo((b['date'] ?? '').toString()));
      return rows;
    }

    if (_reportKey == 'Day Book') {
      return vouchersAll.where((v) => _inRange(v['voucher_date']?.toString(), _from, _to)).toList();
    }

    if (_reportKey == 'Trial Balance') {
      final ledger = <String, Map<String, dynamic>>{};
      for (final v in vouchersAll.where((v) => _inRange(v['voucher_date']?.toString(), _from, _to))) {
        final lines = (v['lines'] as List?) ?? const [];
        for (final line in lines.whereType<Map>()) {
          final m = line.cast<String, dynamic>();
          final code = (m['account_code'] ?? '-').toString();
          final name = (m['account_name'] ?? code).toString();
          final curr = ledger[code] ?? {'account_code': code, 'account_name': name, 'debit': 0, 'credit': 0};
          curr['debit'] = _toNum(curr['debit']) + _toNum(m['debit']);
          curr['credit'] = _toNum(curr['credit']) + _toNum(m['credit']);
          ledger[code] = curr;
        }
      }
      return ledger.values.toList();
    }

    if (_reportKey == 'Low Stock Summary') {
      return productsAll.where((e) => _toNum(e['reorder_level']) > 0 && _toNum(e['in_stock']) <= _toNum(e['reorder_level'])).toList();
    }

    return [];
  }

  @override
  Widget build(BuildContext context) {
    return FeatureScaffold(
      title: _reportKey,
      actions: [
        IconButton(
          tooltip: 'Refresh',
          onPressed: _loading ? null : _load,
          icon: const Icon(Icons.refresh),
        ),
        IconButton(
          tooltip: 'Export PDF',
          onPressed: _loading
              ? null
              : () => Navigator.pushNamed(
                    context,
                    '/reports/preview',
                    arguments: {
                      ...widget.args,
                      'rows': _rows,
                    },
                  ),
          icon: const Icon(Icons.picture_as_pdf_outlined),
        ),
        IconButton(
          tooltip: 'Export XLS',
          onPressed: _loading
              ? null
              : () {
                  ExportUtils.exportCsvAsXls(
                    context,
                    fileBaseName: '${_reportKey.replaceAll(' ', '_')}_${DateTime.now().millisecondsSinceEpoch}',
                    rows: _toExportRows(_reportKey, _rows),
                  );
                },
          icon: const Icon(Icons.table_view_outlined),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text('From ${_ymd(_from)} to ${_ymd(_to)}'),
            ),
          ),
          const SizedBox(height: 12),
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Text(_error!),
              ),
            )
          else if (_rows.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('No data found for this filter.'),
            )
          else
            ..._rows.map(
              (r) => Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  title: Text((r['invoice_no'] ?? r['voucher_no'] ?? r['label'] ?? r['account_code'] ?? r['ref'] ?? r['name'] ?? '-').toString()),
                  subtitle: Text((r['invoice_date'] ?? r['voucher_date'] ?? r['date'] ?? r['party_name'] ?? r['account_name'] ?? r['status'] ?? '').toString()),
                  trailing: Text(
                    r.containsKey('net_total')
                        ? _toNum(r['net_total']).toStringAsFixed(2)
                        : (r.containsKey('value')
                            ? _toNum(r['value']).toStringAsFixed(2)
                            : ((r.containsKey('debit') || r.containsKey('credit'))
                                ? 'Dr ${_toNum(r['debit']).toStringAsFixed(2)} / Cr ${_toNum(r['credit']).toStringAsFixed(2)}'
                                : '')),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  List<List<String>> _toExportRows(String reportKey, List<Map<String, dynamic>> rows) {
    if (rows.isEmpty) {
      return const [
        ['Info'],
        ['No data'],
      ];
    }

    if (reportKey == 'Sales Report') {
      final out = <List<String>>[
        ['Label', 'Value'],
      ];
      for (final r in rows) {
        out.add([
          (r['label'] ?? '-').toString(),
          _toNum(r['value']).toStringAsFixed(2),
        ]);
      }
      return out;
    }

    final out = <List<String>>[
      ['Data'],
    ];
    for (final r in rows) {
      out.add([r.toString()]);
    }
    return out;
  }
}
