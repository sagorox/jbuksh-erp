import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

import '../../core/api.dart';
import '../../core/role_utils.dart';
import 'feature_scaffold.dart';

class ScheduleScreen extends StatefulWidget {
  const ScheduleScreen({super.key});

  @override
  State<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends State<ScheduleScreen> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _schedules = [];
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _territories = [];

  String get _role => RoleUtils.normalize((((Hive.box('auth').get('user') as Map?) ?? const {})['role'] ?? '').toString());
  bool get _canManage => _role == RoleUtils.superAdmin || _role == RoleUtils.rsm;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final sched = await Api.getJson(_canManage ? '/api/v1/schedules' : '/api/v1/schedules/my');
      final users = _canManage ? await Api.getJson('/api/v1/users') : {'users': []};
      final territories = _canManage ? await _getTerritories() : {'territories': []};
      setState(() {
        _schedules = (((sched['schedules'] ?? sched['items']) as List?) ?? const [])
            .whereType<Map>()
            .map((e) => e.cast<String, dynamic>())
            .toList();
        _users = ((users['users'] as List?) ?? const []).whereType<Map>().map((e) => e.cast<String, dynamic>()).toList();
        _territories = ((territories['territories'] as List?) ?? const []).whereType<Map>().map((e) => e.cast<String, dynamic>()).toList();
      });
    } catch (e) {
      setState(() => _error = e.toString().replaceAll('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<Map<String, dynamic>> _getTerritories() async {
    try {
      return await Api.getJson('/api/v1/geo/territories');
    } catch (_) {
      return Api.getJson('/api/v1/territories');
    }
  }

  Future<void> _createSchedule() async {
    final nameCtrl = TextEditingController();
    DateTime start = DateTime.now();
    DateTime end = DateTime.now().add(const Duration(days: 6));
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Create Schedule'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Schedule name')),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final picked = await showDatePicker(context: context, initialDate: start, firstDate: DateTime(2020), lastDate: DateTime(2100));
                        if (picked != null) setLocal(() => start = picked);
                      },
                      child: Text('Start ${start.toString().split(' ').first}'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final picked = await showDatePicker(context: context, initialDate: end, firstDate: DateTime(2020), lastDate: DateTime(2100));
                        if (picked != null) setLocal(() => end = picked);
                      },
                      child: Text('End ${end.toString().split(' ').first}'),
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await Api.postJson('/api/v1/schedules', {
      'name': nameCtrl.text.trim(),
      'start_date': start.toString().split(' ').first,
      'end_date': end.toString().split(' ').first,
    });
    await _load();
  }

  Future<void> _assignSchedule() async {
    int? scheduleId;
    int? userId;
    int? territoryId;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('Assign Schedule'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<int>(
                items: _schedules.map((e) {
                  final id = ((e['schedule']?['id'] ?? e['id']) as num).toInt();
                  final name = (e['schedule']?['name'] ?? e['name']).toString();
                  return DropdownMenuItem(value: id, child: Text(name));
                }).toList(),
                onChanged: (v) => setLocal(() => scheduleId = v),
                decoration: const InputDecoration(labelText: 'Schedule'),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                items: _users.map((e) => DropdownMenuItem(value: (e['id'] as num).toInt(), child: Text('${e['full_name']} (${e['role']})'))).toList(),
                onChanged: (v) => setLocal(() => userId = v),
                decoration: const InputDecoration(labelText: 'User'),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<int?>(
                items: [
                  const DropdownMenuItem<int?>(value: null, child: Text('No territory')),
                  ..._territories.map((e) => DropdownMenuItem<int?>(value: (e['id'] as num).toInt(), child: Text('${e['name']} (${e['code']})'))),
                ],
                onChanged: (v) => setLocal(() => territoryId = v),
                decoration: const InputDecoration(labelText: 'Territory'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Assign')),
          ],
        ),
      ),
    );
    if (ok != true || scheduleId == null || userId == null) return;
    try {
      await Api.postJson('/api/v1/schedules/$scheduleId/assign', {
        'user_id': userId,
        'territory_id': territoryId,
      });
    } catch (_) {
      await Api.postJson('/api/v1/schedules/assign', {
        'work_schedule_id': scheduleId,
        'user_id': userId,
        'territory_id': territoryId,
      });
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return FeatureScaffold(
      title: 'Work Schedule',
      actions: [
        if (_canManage) IconButton(icon: const Icon(Icons.playlist_add), onPressed: _createSchedule),
        if (_canManage) IconButton(icon: const Icon(Icons.assignment_ind), onPressed: _assignSchedule),
        IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
      ],
      child: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(16), child: Text(_error!)))
              : _schedules.isEmpty
                  ? const Center(child: Text('No schedule found'))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: _schedules.length,
                      itemBuilder: (context, index) {
                        final s = _schedules[index];
                        final data = (s['schedule'] is Map) ? (s['schedule'] as Map).cast<String, dynamic>() : s;
                        final subtitle = _canManage
                            ? '${data['start_date'] ?? '-'} → ${data['end_date'] ?? '-'}'
                            : '${data['start_date'] ?? '-'} → ${data['end_date'] ?? '-'} • Territory ${s['territory_id'] ?? '-'}';
                        return Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          child: ListTile(
                            leading: const Icon(Icons.event_note_outlined),
                            title: Text((data['name'] ?? 'Schedule').toString()),
                            subtitle: Text(subtitle),
                          ),
                        );
                      },
                    ),
    );
  }
}
