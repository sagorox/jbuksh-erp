import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

import '../../core/api.dart';
import '../../routes.dart';
import 'feature_scaffold.dart';

class TransactionDetailsScreen extends StatefulWidget {
  final Map<String, dynamic> invoice;
  const TransactionDetailsScreen({super.key, required this.invoice});

  @override
  State<TransactionDetailsScreen> createState() =>
      _TransactionDetailsScreenState();
}

class _TransactionDetailsScreenState extends State<TransactionDetailsScreen> {
  bool _actionBusy = false;

  String money(num v) => v.toStringAsFixed(2);

  Map<String, dynamic> get inv => widget.invoice;
  String get _invoiceUuid => (inv['uuid'] ?? '').toString();
  int? get _invoiceId => int.tryParse((inv['id'] ?? '').toString());

  String get invoiceNo {
    final serverNo = (inv['server_invoice_no'] ?? '').toString().trim();
    if (serverNo.isNotEmpty) return serverNo;
    return (inv['invoice_no'] ?? '-').toString();
  }

  bool get isTempInvoiceNo {
    final serverNo = (inv['server_invoice_no'] ?? '').toString().trim();
    return serverNo.isEmpty && invoiceNo.startsWith('DRAFT-');
  }

  String get status => (inv['status'] ?? '').toString();

  List<Map<String, dynamic>> get items {
    final raw = inv['items'];
    if (raw is List) {
      return raw
          .whereType<Map>()
          .map((e) => e.cast<String, dynamic>())
          .toList();
    }
    return const [];
  }

  bool _isSameInvoice(Map<String, dynamic> row) {
    final rowUuid = (row['uuid'] ?? '').toString();
    if (_invoiceUuid.isNotEmpty && rowUuid == _invoiceUuid) {
      return true;
    }

    final rowId = int.tryParse((row['id'] ?? '').toString());
    final id = _invoiceId;
    return id != null && rowId == id;
  }

  Future<Map<String, dynamic>?> _upsertLocalInvoice(
    Map<String, dynamic> patch,
  ) async {
    final box = Hive.box('invoices');

    for (final key in box.keys) {
      final raw = box.get(key);
      if (raw is! Map) continue;
      final row = Map<String, dynamic>.from(raw.cast<String, dynamic>());
      if (!_isSameInvoice(row)) continue;

      final updated = <String, dynamic>{...row, ...patch};
      await box.put(key, updated);
      return updated;
    }

    final updated = <String, dynamic>{...inv, ...patch};
    final key = _invoiceUuid.isNotEmpty
        ? _invoiceUuid
        : (_invoiceId?.toString() ?? '');
    if (key.isNotEmpty) {
      await box.put(key, updated);
    } else {
      await box.add(updated);
    }
    return updated;
  }

  Future<bool> _removeLocalInvoice() async {
    final box = Hive.box('invoices');
    for (final key in box.keys) {
      final raw = box.get(key);
      if (raw is! Map) continue;
      final row = Map<String, dynamic>.from(raw.cast<String, dynamic>());
      if (_isSameInvoice(row)) {
        await box.delete(key);
        return true;
      }
    }
    return false;
  }

  Future<void> _queueInvoiceUpsert(Map<String, dynamic> payload) async {
    if (_invoiceUuid.isEmpty) return;

    await Hive.box('outboxBox').add({
      'deviceId': Hive.box('auth').get('deviceId') ?? 'unknown',
      'entity': 'invoice',
      'op': 'UPSERT',
      'uuid': _invoiceUuid,
      'version': (payload['version'] ?? 1),
      'payload': payload,
      'queued_at': DateTime.now().toIso8601String(),
    });
  }

  bool _isLikelyOffline(Object e) {
    final m = e.toString().toLowerCase();
    return m.contains('socketexception') ||
        m.contains('failed host lookup') ||
        m.contains('connection refused') ||
        m.contains('network is unreachable') ||
        m.contains('timed out') ||
        m.contains('clientexception');
  }

  void _showMessage(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _markSubmitted() async {
    if (_actionBusy) return;
    if (_invoiceUuid.isEmpty && _invoiceId == null) return;

    setState(() => _actionBusy = true);
    final now = DateTime.now().toIso8601String();

    try {
      final serverId = _invoiceId;
      if (serverId != null && !isTempInvoiceNo) {
        await Api.postJson('/api/v1/invoices/$serverId/submit', {});
        final updated = await _upsertLocalInvoice({
          'status': 'PENDING_APPROVAL',
          'updated_at_client': now,
          'sync_status': 'clean',
        });
        if (updated != null && mounted) {
          setState(() => widget.invoice.addAll(updated));
        }
        _showMessage('Submitted for approval.');
        return;
      }

      final updated = await _upsertLocalInvoice({
        'status': 'PENDING_APPROVAL',
        'updated_at_client': now,
        'sync_status': 'dirty',
      });
      if (updated != null) {
        await _queueInvoiceUpsert(updated);
        if (mounted) setState(() => widget.invoice.addAll(updated));
      }
      _showMessage('Submitted for approval (offline queued).');
    } catch (e) {
      if (_isLikelyOffline(e)) {
        final updated = await _upsertLocalInvoice({
          'status': 'PENDING_APPROVAL',
          'updated_at_client': now,
          'sync_status': 'dirty',
        });
        if (updated != null) {
          await _queueInvoiceUpsert(updated);
          if (mounted) setState(() => widget.invoice.addAll(updated));
        }
        _showMessage('No network. Submission queued.');
      } else {
        _showMessage(
          'Submit failed: ${e.toString().replaceAll('Exception: ', '')}',
        );
      }
    } finally {
      if (mounted) setState(() => _actionBusy = false);
    }
  }

  Future<void> _cancelOrDeleteDraft() async {
    final canServerCancel = !isTempInvoiceNo && _invoiceId != null;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(canServerCancel ? 'Cancel invoice?' : 'Delete draft?'),
        content: Text(
          canServerCancel
              ? 'This will move the invoice to CANCELLED status.'
              : 'This will remove it from offline storage.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Back'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(canServerCancel ? 'Confirm Cancel' : 'Delete'),
          ),
        ],
      ),
    );

    if (ok != true) return;
    if (_actionBusy) return;

    setState(() => _actionBusy = true);
    final now = DateTime.now().toIso8601String();

    try {
      final serverId = _invoiceId;
      if (serverId != null && !isTempInvoiceNo) {
        await Api.postJson('/api/v1/invoices/$serverId/cancel', {});
        final updated = await _upsertLocalInvoice({
          'status': 'CANCELLED',
          'updated_at_client': now,
          'sync_status': 'clean',
        });
        if (updated != null && mounted) {
          setState(() => widget.invoice.addAll(updated));
        }
        _showMessage('Invoice cancelled.');
        return;
      }

      final removed = await _removeLocalInvoice();
      if (removed && mounted) {
        Navigator.of(context).pop();
      }
      _showMessage('Draft deleted.');
    } catch (e) {
      if (_isLikelyOffline(e)) {
        final updated = await _upsertLocalInvoice({
          'status': 'CANCELLED',
          'updated_at_client': now,
          'sync_status': 'dirty',
        });
        if (updated != null) {
          await _queueInvoiceUpsert(updated);
          if (mounted) setState(() => widget.invoice.addAll(updated));
        }
        _showMessage('No network. Cancellation queued.');
      } else {
        _showMessage(
          'Cancel failed: ${e.toString().replaceAll('Exception: ', '')}',
        );
      }
    } finally {
      if (mounted) setState(() => _actionBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final partyName = ((inv['party']?['name']) ?? inv['party_name'] ?? '-')
        .toString();
    final date = (inv['invoice_date'] ?? '-').toString();
    final time = (inv['invoice_time'] ?? '').toString();
    final net = (inv['net_total'] is num)
        ? inv['net_total'] as num
        : num.tryParse('${inv['net_total']}') ?? 0;
    final due = (inv['due_amount'] is num)
        ? inv['due_amount'] as num
        : num.tryParse('${inv['due_amount']}') ?? 0;

    return FeatureScaffold(
      title: 'Transaction Details',
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          partyName,
                          style: const TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      _StatusChip(status: status),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(child: Text('Invoice: $invoiceNo')),
                      if (isTempInvoiceNo)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.orange.shade100,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            'TEMP',
                            style: TextStyle(
                              fontSize: 10,
                              color: Colors.orange.shade900,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                    ],
                  ),
                  Text('Date: $date${time.isEmpty ? '' : ' | $time'}'),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Net Total',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        'Tk ${money(net)}',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Balance Due',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        'Tk ${money(due)}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Items',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  if (items.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 10),
                      child: Text('No items.'),
                    )
                  else
                    ...items.map((it) {
                      final name = (it['name'] ?? '-').toString();
                      final qty = (it['qty'] is num)
                          ? it['qty'] as num
                          : num.tryParse('${it['qty']}') ?? 0;
                      final free = (it['free_qty'] is num)
                          ? it['free_qty'] as num
                          : num.tryParse('${it['free_qty']}') ?? 0;
                      final price = (it['unit_price'] is num)
                          ? it['unit_price'] as num
                          : num.tryParse('${it['unit_price']}') ?? 0;
                      final total = (it['line_total'] is num)
                          ? it['line_total'] as num
                          : num.tryParse('${it['line_total']}') ?? 0;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    name,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  Text(
                                    'Qty $qty | Free $free | Price Tk ${money(price)}',
                                    style: const TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              'Tk ${money(total)}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  OutlinedButton.icon(
                    onPressed: () {
                      Navigator.of(
                        context,
                      ).pushNamed(RouteNames.invoicePreview, arguments: inv);
                    },
                    icon: const Icon(Icons.picture_as_pdf_outlined),
                    label: const Text('PDF'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Share later.')),
                      );
                    },
                    icon: const Icon(Icons.share_outlined),
                    label: const Text('Share'),
                  ),
                  if (status == 'DRAFT')
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _actionBusy ? null : _markSubmitted,
                      icon: const Icon(Icons.send),
                      label: const Text('Submit For Approval'),
                    ),
                  if (status == 'DRAFT')
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE53935),
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _actionBusy ? null : _cancelOrDeleteDraft,
                      icon: const Icon(Icons.delete_outline),
                      label: Text(
                        (!isTempInvoiceNo && _invoiceId != null)
                            ? 'Cancel Invoice'
                            : 'Delete Draft',
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          OutlinedButton(
            onPressed: () =>
                Navigator.of(context).pushNamed(RouteNames.transactions),
            child: const Text('Back to Transactions'),
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String status;
  const _StatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    final s = status.isEmpty ? 'UNKNOWN' : status;
    Color bg;
    Color fg;
    switch (s) {
      case 'DRAFT':
        bg = Colors.grey.shade200;
        fg = Colors.black87;
        break;
      case 'SUBMITTED':
      case 'PENDING_APPROVAL':
        bg = Colors.orange.shade100;
        fg = Colors.orange.shade900;
        break;
      case 'APPROVED':
        bg = Colors.green.shade100;
        fg = Colors.green.shade900;
        break;
      case 'DECLINED':
        bg = Colors.red.shade100;
        fg = Colors.red.shade900;
        break;
      default:
        bg = Colors.blue.shade100;
        fg = Colors.blue.shade900;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        s,
        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: fg),
      ),
    );
  }
}
