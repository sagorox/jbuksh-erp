import 'dart:convert';
import 'package:http/http.dart' as http;

import 'notification_model.dart';

class NotificationsApiService {
  final String baseUrl;
  final Future<String?> Function() tokenProvider;

  NotificationsApiService({
    required this.baseUrl,
    required this.tokenProvider,
  });

  Future<NotificationListResponse> fetchNotifications() async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl/api/v1/notifications');

    final response = await http.get(
      uri,
      headers: {
        'Content-Type': 'application/json',
        if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
      },
    );

    final data = _decode(response);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Failed to load notifications');
    }

    return NotificationListResponse.fromJson(data);
  }

  Future<void> markRead(int id) async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl/api/v1/notifications/$id/read');

    final response = await http.patch(
      uri,
      headers: {
        'Content-Type': 'application/json',
        if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
      },
    );

    final data = _decode(response);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Failed to mark notification as read');
    }
  }

  Future<void> markAllRead() async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl/api/v1/notifications/read-all');

    final response = await http.patch(
      uri,
      headers: {
        'Content-Type': 'application/json',
        if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
      },
    );

    final data = _decode(response);

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? 'Failed to mark all notifications as read');
    }
  }

  Map<String, dynamic> _decode(http.Response response) {
    if (response.body.isEmpty) return <String, dynamic>{};
    final decoded = jsonDecode(response.body);
    if (decoded is Map<String, dynamic>) return decoded;
    return <String, dynamic>{'data': decoded};
  }
}