import 'package:flutter/material.dart';

import 'feature_scaffold.dart';

class ReportPreviewScreen extends StatelessWidget {
  final Map<String, dynamic> args;
  const ReportPreviewScreen({super.key, required this.args});

  DateTime _dt(String iso) {
    try {
      return DateTime.parse(iso);
    } catch (_) {
      return DateTime.now();
    }
  }

  num _toNum(dynamic v) {
    if (v is num) return v;
    return num.tryParse(v?.toString() ?? '') ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    final reportKey = (args['reportKey'] ?? 'Report').toString();
    final from = _dt(args['from'] ?? DateTime.now().toIso8601String());
    final to = _dt(args['to'] ?? DateTime.now().toIso8601String());
    final rawRows = (args['rows'] as List?) ?? const [];
    final rows = rawRows.whereType<Map>().map((e) => e.cast<String, dynamic>()).toList();

    return FeatureScaffold(
      title: '$reportKey (Preview)',
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Text(
                'From ${from.year}-${from.month.toString().padLeft(2, '0')}-${from.day.toString().padLeft(2, '0')} '
                'to ${to.year}-${to.month.toString().padLeft(2, '0')}-${to.day.toString().padLeft(2, '0')}',
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (rows.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('No data to preview.'),
              ),
            )
          else
            ...rows.map(
              (r) => Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  title: Text((r['label'] ?? r['invoice_no'] ?? r['voucher_no'] ?? r['account_code'] ?? r['ref'] ?? '-').toString()),
                  subtitle: Text((r['invoice_date'] ?? r['voucher_date'] ?? r['date'] ?? r['account_name'] ?? r['status'] ?? '').toString()),
                  trailing: Text(
                    r.containsKey('value')
                        ? _toNum(r['value']).toStringAsFixed(2)
                        : (r.containsKey('net_total')
                            ? _toNum(r['net_total']).toStringAsFixed(2)
                            : ((r.containsKey('debit') || r.containsKey('credit'))
                                ? 'Dr ${_toNum(r['debit']).toStringAsFixed(2)} / Cr ${_toNum(r['credit']).toStringAsFixed(2)}'
                                : '')),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
