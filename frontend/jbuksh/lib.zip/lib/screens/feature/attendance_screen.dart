import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

import '../../core/api.dart';
import '../../core/local_store.dart';
import '../../core/sync_service.dart';
import 'feature_scaffold.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  Map<String, dynamic>? _today;
  bool _busy = false;

  String _yyyyMmDd(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _uuid() {
    final now = DateTime.now().microsecondsSinceEpoch;
    return 'a-$now-${(now % 100000).toString().padLeft(5, '0')}';
  }

  int? _resolveUserId() => LocalStore.userId();

  int? _resolveTerritoryId() {
    final user = (Hive.box('auth').get('user') as Map?) ?? {};
    final territoryIds = ((user['territory_ids'] as List?) ?? const []).toList();
    final raw = user['territory_id'] ??
        (user['territory'] is Map ? (user['territory'] as Map)['id'] : null) ??
        (territoryIds.isNotEmpty ? territoryIds.first : null);
    if (raw is int) return raw;
    if (raw is num) return raw.toInt();
    return int.tryParse(raw?.toString() ?? '');
  }

  void _loadToday() {
    final box = Hive.box('attendance');
    final uid = _resolveUserId();
    final todayKey = _yyyyMmDd(DateTime.now());

    Map<String, dynamic>? found;
    for (int i = 0; i < box.length; i++) {
      final v = box.getAt(i);
      if (v is Map) {
        final m = v.cast<String, dynamic>();
        final rowDate = (m['attendance_date'] ?? m['att_date'] ?? '').toString();
        if ((m['user_id'] == uid) && rowDate == todayKey && (m['is_deleted'] != true)) {
          found = m;
          break;
        }
      }
    }

    if (mounted) {
      setState(() => _today = found);
    }
  }

  @override
  void initState() {
    super.initState();
    _loadToday();
  }

  Future<void> _upsertLocalAttendance(Map<String, dynamic> row) async {
    final box = Hive.box('attendance');
    final uuid = (row['uuid'] ?? '').toString();
    final serverId = row['id'];

    for (int i = 0; i < box.length; i++) {
      final v = box.getAt(i);
      if (v is! Map) continue;
      final m = v.cast<String, dynamic>();
      final sameUuid = uuid.isNotEmpty && (m['uuid'] ?? '').toString() == uuid;
      final sameId = serverId != null && m['id'] == serverId;
      if (sameUuid || sameId) {
        await box.putAt(i, row);
        _loadToday();
        return;
      }
    }

    await box.add(row);
    _loadToday();
  }

  Future<Map<String, dynamic>> _ensureLocalDraft() async {
    if (_today != null) return Map<String, dynamic>.from(_today!);

    final territoryId = _resolveTerritoryId();
    final userId = _resolveUserId();
    if (territoryId == null || userId == null) {
      throw Exception('No territory assigned to this user.');
    }

    final now = DateTime.now();
    final row = <String, dynamic>{
      'id': -now.millisecondsSinceEpoch,
      'uuid': _uuid(),
      'user_id': userId,
      'territory_id': territoryId,
      'attendance_date': _yyyyMmDd(now),
      'att_date': _yyyyMmDd(now),
      'check_in': null,
      'check_in_at': null,
      'check_out': null,
      'check_out_at': null,
      'status': 'DRAFT',
      'note': null,
      'version': 1,
      'updated_at_client': now.toUtc().toIso8601String(),
    };

    await _upsertLocalAttendance(row);
    return row;
  }

  Future<void> _safeRun(Future<void> Function() job) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await job();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceAll('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _checkIn() async {
    await _safeRun(() async {
      final local = await _ensureLocalDraft();
      try {
        final res = await Api.postJson('/api/v1/attendance/check-in', {
          'territory_id': local['territory_id'],
          'note': local['note'],
        });
        final server = (res['attendance'] as Map?)?.cast<String, dynamic>() ??
            <String, dynamic>{};
        if (server.isNotEmpty) {
          server['uuid'] = local['uuid'];
          server['attendance_date'] = server['att_date'] ?? server['attendance_date'];
          server['check_in'] = server['check_in_at'];
          server['check_out'] = server['check_out_at'];
          server['updated_at_client'] = DateTime.now().toUtc().toIso8601String();
          await _upsertLocalAttendance(server);
        }
      } catch (_) {
        final now = DateTime.now().toUtc().toIso8601String();
        final updated = Map<String, dynamic>.from(local);
        updated['check_in'] ??= now;
        updated['check_in_at'] ??= now;
        updated['status'] = 'PENDING';
        updated['updated_at_client'] = now;
        updated['version'] = (updated['version'] is int)
            ? (updated['version'] as int) + 1
            : 1;
        await _upsertLocalAttendance(updated);
        await SyncService.enqueue(
          entity: 'attendance',
          op: 'UPSERT',
          uuid: (updated['uuid'] ?? _uuid()).toString(),
          version: updated['version'] as int,
          payload: updated,
        );
      }
    });
  }

  Future<void> _checkOut() async {
    await _safeRun(() async {
      final local = await _ensureLocalDraft();
      if ((local['check_in'] ?? local['check_in_at']) == null) {
        throw Exception('Check-in first.');
      }

      try {
        final res = await Api.postJson('/api/v1/attendance/check-out', {});
        final server = (res['attendance'] as Map?)?.cast<String, dynamic>() ??
            <String, dynamic>{};
        if (server.isNotEmpty) {
          server['uuid'] = local['uuid'];
          server['attendance_date'] = server['att_date'] ?? server['attendance_date'];
          server['check_in'] = server['check_in_at'];
          server['check_out'] = server['check_out_at'];
          server['updated_at_client'] = DateTime.now().toUtc().toIso8601String();
          await _upsertLocalAttendance(server);
        }
      } catch (_) {
        final now = DateTime.now().toUtc().toIso8601String();
        final updated = Map<String, dynamic>.from(local);
        updated['check_out'] ??= now;
        updated['check_out_at'] ??= now;
        updated['status'] = 'PENDING';
        updated['updated_at_client'] = now;
        updated['version'] = (updated['version'] is int)
            ? (updated['version'] as int) + 1
            : 1;
        await _upsertLocalAttendance(updated);
        await SyncService.enqueue(
          entity: 'attendance',
          op: 'UPSERT',
          uuid: (updated['uuid'] ?? _uuid()).toString(),
          version: updated['version'] as int,
          payload: updated,
        );
      }
    });
  }

  Future<void> _refreshFromServer() async {
    await _safeRun(() async {
      final userId = _resolveUserId();
      final query = userId == null ? '' : '?user_id=$userId';
      final res = await Api.getJson('/api/v1/attendance$query');
      final list = (res['items'] as List?) ?? (res['attendance'] as List?) ?? const [];
      final box = Hive.box('attendance');
      await box.clear();
      for (final item in list.whereType<Map>()) {
        final row = item.cast<String, dynamic>();
        row['attendance_date'] = row['att_date'] ?? row['attendance_date'];
        row['check_in'] = row['check_in_at'];
        row['check_out'] = row['check_out_at'];
        await box.add(row);
      }
      _loadToday();
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = _today;
    final checkIn = (t?['check_in'] ?? t?['check_in_at'] ?? '').toString();
    final checkOut = (t?['check_out'] ?? t?['check_out_at'] ?? '').toString();
    final status = (t?['status'] ?? 'DRAFT').toString();
    final isSubmitted = status.toUpperCase() == 'APPROVED' ||
        status.toUpperCase() == 'PENDING';

    return FeatureScaffold(
      title: 'Attendance',
      actions: [
        IconButton(
          tooltip: 'Refresh',
          onPressed: _busy ? null : _refreshFromServer,
          icon: const Icon(Icons.refresh),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              leading: const Icon(Icons.event_available_outlined),
              title: Text(
                'Today: ${_yyyyMmDd(DateTime.now())}',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: Text(
                'Status: $status',
              ),
              trailing: _Chip(status),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_busy) const LinearProgressIndicator(),
                  if (_busy) const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _KV(
                          label: 'Check-in',
                          value: checkIn.isEmpty
                              ? '-'
                              : checkIn.split('.').first.replaceAll('T', ' '),
                        ),
                      ),
                      Expanded(
                        child: _KV(
                          label: 'Check-out',
                          value: checkOut.isEmpty
                              ? '-'
                              : checkOut.split('.').first.replaceAll('T', ' '),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: isSubmitted || _busy ? null : _checkIn,
                          icon: const Icon(Icons.login),
                          label: const Text('Check In'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : _checkOut,
                          icon: const Icon(Icons.logout),
                          label: const Text('Check Out'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Online থাকলে backend attendance endpoint এ সাথে সাথে submit হবে, offline থাকলে sync queue তে যাবে।',
                    style: TextStyle(color: Colors.grey.shade700),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _KV extends StatelessWidget {
  final String label;
  final String value;
  const _KV({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
        const SizedBox(height: 4),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  final String status;
  const _Chip(this.status);

  @override
  Widget build(BuildContext context) {
    Color color;
    switch (status.toUpperCase()) {
      case 'APPROVED':
        color = Colors.green;
        break;
      case 'PENDING':
        color = Colors.orange;
        break;
      case 'DECLINED':
        color = Colors.red;
        break;
      default:
        color = Colors.blueGrey;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        status,
        style: TextStyle(color: color, fontWeight: FontWeight.w700),
      ),
    );
  }
}
