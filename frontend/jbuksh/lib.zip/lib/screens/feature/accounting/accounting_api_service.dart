import 'dart:convert';
import 'package:http/http.dart' as http;

import 'accounting_models.dart';

class AccountingApiService {
  final String baseUrl;
  final Future<String?> Function() tokenProvider;

  AccountingApiService({
    required this.baseUrl,
    required this.tokenProvider,
  });

  Future<AccountingSummary> fetchSummary() async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl/api/v1/accounting/summary');

    final response = await http.get(
      uri,
      headers: _headers(token),
    );

    final data = _decode(response);
    _throwIfNeeded(response, data, 'Failed to load accounting summary');

    return AccountingSummary.fromJson(data);
  }

  Future<VoucherListResponse> fetchVouchers() async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl/api/v1/accounting/vouchers');

    final response = await http.get(
      uri,
      headers: _headers(token),
    );

    final data = _decode(response);
    _throwIfNeeded(response, data, 'Failed to load vouchers');

    return VoucherListResponse.fromJson(data);
  }

  Future<VoucherItem> createVoucher({
    required String voucherDate,
    required String voucherType,
    required double amount,
    String? description,
    String status = 'POSTED',
  }) async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl/api/v1/accounting/vouchers');

    final response = await http.post(
      uri,
      headers: _headers(token),
      body: jsonEncode({
        'voucher_date': voucherDate,
        'voucher_type': voucherType,
        'amount': amount,
        'description': description,
        'status': status,
      }),
    );

    final data = _decode(response);
    _throwIfNeeded(response, data, 'Failed to create voucher');

    return VoucherItem.fromJson(Map<String, dynamic>.from(data['voucher'] ?? {}));
  }

  Future<VoucherItem> updateVoucherStatus({
    required int id,
    required String status,
  }) async {
    final token = await tokenProvider();
    final uri = Uri.parse('$baseUrl/api/v1/accounting/vouchers/$id/status');

    final response = await http.patch(
      uri,
      headers: _headers(token),
      body: jsonEncode({
        'status': status,
      }),
    );

    final data = _decode(response);
    _throwIfNeeded(response, data, 'Failed to update voucher status');

    return VoucherItem.fromJson(Map<String, dynamic>.from(data['voucher'] ?? {}));
  }

  Map<String, String> _headers(String? token) {
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  Map<String, dynamic> _decode(http.Response response) {
    if (response.body.isEmpty) return <String, dynamic>{};
    final decoded = jsonDecode(response.body);
    if (decoded is Map<String, dynamic>) return decoded;
    return <String, dynamic>{'data': decoded};
  }

  void _throwIfNeeded(
      http.Response response,
      Map<String, dynamic> data,
      String fallback,
      ) {
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(data['message']?.toString() ?? fallback);
    }
  }
}