import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'accounting_api_service.dart';
import 'accounting_models.dart';

class AccountingScreen extends StatefulWidget {
  const AccountingScreen({super.key});

  @override
  State<AccountingScreen> createState() => _AccountingScreenState();
}

class _AccountingScreenState extends State<AccountingScreen> {
  late final AccountingApiService _api;

  bool _loading = true;
  bool _creating = false;
  String? _error;

  AccountingSummary? _summary;
  List<VoucherItem> _vouchers = const [];

  @override
  void initState() {
    super.initState();

    _api = AccountingApiService(
      baseUrl: _resolveBaseUrl(),
      tokenProvider: _getToken,
    );

    _load();
  }

  String _resolveBaseUrl() {
    // emulator হলে 10.0.2.2
    // physical device হলে তোমার PC IP বসাবে
    return 'http://192.168.0.107:3000';
  }

  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('access_token') ??
        prefs.getString('token') ??
        prefs.getString('jwt_token');
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final results = await Future.wait([
        _api.fetchSummary(),
        _api.fetchVouchers(),
      ]);

      if (!mounted) return;

      setState(() {
        _summary = results[0] as AccountingSummary;
        _vouchers = (results[1] as VoucherListResponse).vouchers;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _showCreateVoucherDialog() async {
    final formKey = GlobalKey<FormState>();
    final amountController = TextEditingController();
    final descriptionController = TextEditingController();
    String voucherType = 'DEBIT';
    String status = 'POSTED';

    final created = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Create Voucher'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    value: voucherType,
                    decoration: const InputDecoration(
                      labelText: 'Voucher Type',
                    ),
                    items: const [
                      DropdownMenuItem(value: 'DEBIT', child: Text('DEBIT')),
                      DropdownMenuItem(value: 'CREDIT', child: Text('CREDIT')),
                    ],
                    onChanged: (v) {
                      voucherType = v ?? 'DEBIT';
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: amountController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Amount',
                    ),
                    validator: (v) {
                      final value = double.tryParse((v ?? '').trim());
                      if (value == null || value <= 0) {
                        return 'Enter valid amount';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: status,
                    decoration: const InputDecoration(
                      labelText: 'Status',
                    ),
                    items: const [
                      DropdownMenuItem(value: 'POSTED', child: Text('POSTED')),
                      DropdownMenuItem(value: 'DRAFT', child: Text('DRAFT')),
                    ],
                    onChanged: (v) {
                      status = v ?? 'POSTED';
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: descriptionController,
                    decoration: const InputDecoration(
                      labelText: 'Description',
                    ),
                    maxLines: 3,
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: _creating
                  ? null
                  : () async {
                if (!formKey.currentState!.validate()) return;

                Navigator.pop(context, true);
              },
              child: const Text('Create'),
            ),
          ],
        );
      },
    );

    if (created != true) {
      amountController.dispose();
      descriptionController.dispose();
      return;
    }

    setState(() {
      _creating = true;
    });

    try {
      final now = DateTime.now();
      final voucherDate =
          '${now.year.toString().padLeft(4, '0')}-'
          '${now.month.toString().padLeft(2, '0')}-'
          '${now.day.toString().padLeft(2, '0')}';

      await _api.createVoucher(
        voucherDate: voucherDate,
        voucherType: voucherType,
        amount: double.parse(amountController.text.trim()),
        description: descriptionController.text.trim().isEmpty
            ? null
            : descriptionController.text.trim(),
        status: status,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Voucher created successfully')),
      );

      await _load();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Create failed: $e')),
      );
    } finally {
      amountController.dispose();
      descriptionController.dispose();

      if (mounted) {
        setState(() {
          _creating = false;
        });
      }
    }
  }

  Future<void> _changeStatus(VoucherItem item, String status) async {
    try {
      await _api.updateVoucherStatus(id: item.id, status: status);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Voucher ${item.voucherNo} updated to $status')),
      );

      await _load();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Status update failed: $e')),
      );
    }
  }

  String _money(double value) => value.toStringAsFixed(2);

  Color _statusColor(String status, BuildContext context) {
    switch (status.toUpperCase()) {
      case 'POSTED':
        return Colors.green.withOpacity(0.12);
      case 'DRAFT':
        return Colors.orange.withOpacity(0.12);
      case 'CANCELLED':
        return Colors.red.withOpacity(0.12);
      default:
        return Theme.of(context).colorScheme.surfaceVariant;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Accounting'),
        actions: [
          IconButton(
            onPressed: _loading ? null : _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: (_loading || _creating) ? null : _showCreateVoucherDialog,
        icon: _creating
            ? const SizedBox(
          height: 18,
          width: 18,
          child: CircularProgressIndicator(strokeWidth: 2),
        )
            : const Icon(Icons.add),
        label: const Text('Add Voucher'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 120),
          const Icon(Icons.error_outline, size: 48),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              _error!,
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: ElevatedButton(
              onPressed: _load,
              child: const Text('Retry'),
            ),
          ),
        ],
      );
    }

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(12),
      children: [
        _buildSummaryCard(),
        const SizedBox(height: 12),
        Text(
          'Vouchers',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        if (_vouchers.isEmpty)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('No vouchers found'),
            ),
          )
        else
          ..._vouchers.map(_buildVoucherCard),
        const SizedBox(height: 80),
      ],
    );
  }

  Widget _buildSummaryCard() {
    final s = _summary;
    if (s == null) {
      return const SizedBox.shrink();
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: _MetricTile(label: 'Total', value: '${s.total}')),
                Expanded(child: _MetricTile(label: 'Posted', value: '${s.posted}')),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _MetricTile(label: 'Draft', value: '${s.draft}')),
                Expanded(child: _MetricTile(label: 'Cancelled', value: '${s.cancelled}')),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: _MetricTile(label: 'Debit', value: _money(s.debit))),
                Expanded(child: _MetricTile(label: 'Credit', value: _money(s.credit))),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _MetricTile(label: 'Balance', value: _money(s.balance))),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVoucherCard(VoucherItem item) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    item.voucherNo,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    color: _statusColor(item.status, context),
                  ),
                  child: Text(item.status),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('Date: ${item.voucherDate}'),
            Text('Type: ${item.voucherType}'),
            Text('Amount: ${_money(item.amount)}'),
            if ((item.description ?? '').trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('Description: ${item.description}'),
              ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (item.status != 'POSTED')
                  OutlinedButton(
                    onPressed: () => _changeStatus(item, 'POSTED'),
                    child: const Text('Mark POSTED'),
                  ),
                if (item.status != 'DRAFT')
                  OutlinedButton(
                    onPressed: () => _changeStatus(item, 'DRAFT'),
                    child: const Text('Mark DRAFT'),
                  ),
                if (item.status != 'CANCELLED')
                  OutlinedButton(
                    onPressed: () => _changeStatus(item, 'CANCELLED'),
                    child: const Text('Cancel'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  final String label;
  final String value;

  const _MetricTile({
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 4),
        Text(label),
      ],
    );
  }
}