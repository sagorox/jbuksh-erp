import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { TerritoryScoped } from '../auth/territory-scoped.decorator';
import { TerritoryScopeGuard } from '../auth/territory-scope.guard';
import { InvoicesService } from './invoices.service';

@Controller('api/v1/invoices')
@UseGuards(JwtAuthGuard, TerritoryScopeGuard)
@TerritoryScoped()
export class InvoicesController {
  constructor(private readonly invoices: InvoicesService) {}

  @Post()
  createDraft(
    @Req() req: any,
    @Body()
    body: {
      territory_id: number;
      party_id: number;
      invoice_date: string;
      invoice_time: string;
      discount_percent?: number;
      discount_amount?: number;
      remarks?: string | null;
    },
  ) {
    const mpo_user_id = req.user.sub;
    return this.invoices.createDraft({ mpo_user_id, ...body });
  }

  @Post(':id/items')
  addItems(
    @Param('id') id: string,
    @Body() body: { items: Array<{ product_id: number; qty: number; free_qty?: number; unit_price: number }> },
  ) {
    return this.invoices.addItems(Number(id), body.items);
  }

  @Post(':id/submit')
  submit(@Req() req: any, @Param('id') id: string) {
    return this.invoices.submit(Number(id), req.user);
  }

  @Post(':id/cancel')
  cancel(@Req() req: any, @Param('id') id: string) {
    return this.invoices.cancel(Number(id), req.user);
  }

  @Post(':id/generate-pdf')
  generatePdf(@Param('id') id: string) {
    return this.invoices.generatePdf(Number(id));
  }

  @Get()
  list(
    @Query('status') status?: string,
    @Query('party_id') party_id?: string,
  ) {
    return this.invoices.list(
      status,
      party_id ? Number(party_id) : undefined,
    );
  }
}