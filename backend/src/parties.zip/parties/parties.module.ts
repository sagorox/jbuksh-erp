import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PartyEntity } from './party.entity';
import { PartiesController } from './parties.controller';
import { PartiesService } from './parties.service';
import { GeoModule } from '../geo/geo.module';
import { UserEntity } from '../users/user.entity';

@Module({
  imports: [TypeOrmModule.forFeature([PartyEntity, UserEntity]), GeoModule],
  controllers: [PartiesController],
  providers: [PartiesService],
})
export class PartiesModule {}
